"""obscura.cli — Claude Code-style REPL for Obscura.

Single entry point: ``obscura`` drops into an interactive REPL.
Slash commands (``/help``, ``/agent``, ``/session``, etc.) for actions;
everything else is a chat message sent to the backend.

Usage::

    # Interactive REPL (default)
    obscura
    obscura -b claude
    obscura -b codex

    # Single-shot
    obscura "explain this code"
    obscura -b claude -m claude-sonnet-4-5-20250929 "summarize"
"""

from __future__ import annotations

import asyncio
import uuid
from pathlib import Path
from typing import Any

import click

from obscura.cli.commands import (
    COMPLETIONS,
    REPLContext,
    _FILE_WRITE_TOOLS,
    handle_command,
)
from obscura.cli.prompt import (
    bordered_prompt,
    confirm_prompt_async,
    create_prompt_session,
)
from obscura.cli.render import (
    StreamRenderer,
    console,
    print_banner,
    render_plan,
)
from prompt_toolkit.patch_stdout import patch_stdout
from obscura.cli import trace as trace_mod
from obscura.core.client import ObscuraClient
from obscura.core.event_store import SQLiteEventStore, SessionStatus
from obscura.core.paths import resolve_obscura_home
from obscura.core.types import AgentEventKind, Backend, SessionRef, ToolChoice


# ---------------------------------------------------------------------------
# MCP discovery
# ---------------------------------------------------------------------------


def _discover_mcp() -> tuple[list[dict[str, Any]], list[str]]:
    """Auto-discover MCP servers from ~/.obscura/mcp/. Returns (configs, names)."""
    try:
        from obscura.integrations.mcp.config_loader import (
            build_runtime_server_configs,
            discover_mcp_servers,
        )

        discovered = discover_mcp_servers()
        if discovered:
            configs = build_runtime_server_configs(discovered)
            names = [s.name for s in discovered]
            return configs, names
    except Exception:
        pass
    return [], []


# ---------------------------------------------------------------------------
# Tool confirmation callback
# ---------------------------------------------------------------------------


async def _cli_confirm(ctx: REPLContext, tool_name: str, tool_input: dict[str, Any]) -> bool:
    """Prompt user to approve a tool call. Returns True to allow."""
    if tool_name in ctx.confirm_always:
        return True

    console.print(f"\n[yellow]Tool:[/] [bold]{tool_name}[/]")
    for k, v in tool_input.items():
        sv = str(v)
        if len(sv) > 80:
            sv = sv[:77] + "..."
        console.print(f"  [dim]{k}=[/]{sv}")

    answer = await confirm_prompt_async("Allow? [y/n/always] ")

    if answer == "always":
        ctx.confirm_always.add(tool_name)
        return True
    return answer in ("y", "yes")


# ---------------------------------------------------------------------------
# Vector memory tool call tracking
# ---------------------------------------------------------------------------

_vstore: object | None = None  # lazy-initialized VectorMemoryStore


def _get_vstore() -> object | None:
    """Lazy-init the vector memory store for CLI user."""
    global _vstore
    if _vstore is not None:
        return _vstore
    try:
        import getpass
        from obscura.auth.models import AuthenticatedUser
        from obscura.vector_memory.store import VectorMemoryStore

        _cli_user = AuthenticatedUser(
            user_id=f"cli:{getpass.getuser()}",
            email="",
            roles=("admin",),
            org_id=None,
            token_type="cli",
            raw_token="",
        )
        _vstore = VectorMemoryStore.for_user(_cli_user)
    except Exception:
        pass
    return _vstore


def _track_tool_event_to_vector(ev: Any, ctx: REPLContext) -> None:
    """Fire-and-forget: write tool call / result summaries to vector memory."""
    import asyncio as _asyncio

    vstore = _get_vstore()
    if vstore is None:
        return

    if ev.kind == AgentEventKind.TOOL_CALL:
        tool_name = getattr(ev, "tool_name", "")
        tool_input = getattr(ev, "tool_input", {})
        key = f"tool_call:{ctx.session_id}:{getattr(ev, 'tool_use_id', '')}"
        text = (
            f"TOOL_CALL session={ctx.session_id} tool={tool_name} "
            f"input={str(tool_input)[:500]}"
        )
        metadata = {
            "kind": "tool_call",
            "tool": tool_name,
            "session_id": ctx.session_id,
        }
        try:
            loop = _asyncio.get_event_loop()
            if loop.is_running():
                _asyncio.ensure_future(vstore.set(key, text, metadata=metadata))
        except Exception:
            pass

    elif ev.kind == AgentEventKind.TOOL_RESULT:
        tool_use_id = getattr(ev, "tool_use_id", "")
        result = getattr(ev, "tool_result", "")
        key = f"tool_result:{ctx.session_id}:{tool_use_id}"
        text = (
            f"TOOL_RESULT session={ctx.session_id} "
            f"result={str(result)[:500]}"
        )
        metadata = {
            "kind": "tool_result",
            "session_id": ctx.session_id,
        }
        try:
            loop = _asyncio.get_event_loop()
            if loop.is_running():
                _asyncio.ensure_future(vstore.set(key, text, metadata=metadata))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# File change tracking
# ---------------------------------------------------------------------------


def _track_file_event(event: AgentEventKind, ctx: REPLContext, ev: Any) -> None:
    """Track file modifications for /diff."""
    if ev.kind == AgentEventKind.TOOL_CALL and ev.tool_name in _FILE_WRITE_TOOLS:
        path = ev.tool_input.get("path") or ev.tool_input.get("file_path", "")
        if path:
            try:
                before = Path(path).read_text()
            except (FileNotFoundError, OSError):
                before = ""
            ctx._pending_file_reads[ev.tool_use_id] = (path, before)

    elif ev.kind == AgentEventKind.TOOL_RESULT and ev.tool_use_id in ctx._pending_file_reads:
        path, before = ctx._pending_file_reads.pop(ev.tool_use_id)
        try:
            after = Path(path).read_text()
        except (FileNotFoundError, OSError):
            after = ""
        if after != before:
            ctx.add_file_change(path, before, after)


# ---------------------------------------------------------------------------
# Plan parsing
# ---------------------------------------------------------------------------


def _maybe_parse_plan(response_text: str, ctx: REPLContext) -> None:
    """If in PLAN mode, attempt to parse a structured plan from the response."""
    mm = ctx._mode_manager
    if mm is None:
        return

    from obscura.cli.app.modes import TUIMode

    if mm.current != TUIMode.PLAN:
        return

    if not response_text.strip():
        return

    from obscura.cli.app.modes import Plan

    plan = Plan.parse(response_text)
    if plan.steps:
        mm.active_plan = plan
        render_plan(plan)


# ---------------------------------------------------------------------------
# Chat message dispatch
# ---------------------------------------------------------------------------


async def send_message(
    ctx: REPLContext,
    text: str,
    loop_kwargs: dict[str, Any],
    external_status: object | None = None,
) -> str:
    """Send a chat message and stream the response with Markdown rendering.

    Returns the accumulated assistant text.
    """
    renderer = StreamRenderer(external_status=external_status)
    # Register active renderer so prompt can expand previews while streaming
    try:
        from obscura.cli.render import set_active_renderer

        set_active_renderer(renderer)
    except Exception:
        pass
    accumulated: list[str] = []

    # Build confirm callback if enabled
    confirm_cb = None
    if ctx.confirm_enabled:
        from obscura.core.types import ToolCallInfo

        async def confirm_cb(tc: ToolCallInfo) -> bool:
            return await _cli_confirm(ctx, tc.name, tc.input)

    # Start streaming
    stream = ctx.client.run_loop(
        text,
        max_turns=ctx.max_turns,
        event_store=ctx.store,
        session_id=ctx.session_id,
        auto_complete=False,
        on_confirm=confirm_cb,
        **loop_kwargs,
    )

    try:
        # Ensure any console printing during streaming doesn't clobber an active prompt.
        with patch_stdout():
            async for event in stream:
                renderer.handle(event)
                # record a lightweight trace entry
                try:
                    preview = ""
                    if getattr(event, "text", None):
                        preview = event.text[:200]
                    elif getattr(event, "tool_result", None):
                        preview = str(event.tool_result)[:200]
                    elif getattr(event, "tool_input", None):
                        preview = str(event.tool_input)[:200]
                    tool_names = [event.tool_name] if getattr(event, "tool_name", None) else []
                    trace_mod.append_event(event.kind.name, preview=preview, tool_names=tool_names)
                except Exception:
                    pass

                if event.kind == AgentEventKind.TEXT_DELTA:
                    accumulated.append(event.text)
                _track_file_event(event.kind, ctx, event)
                # Store tool calls + results to vector memory for later recall
                try:
                    _track_tool_event_to_vector(event, ctx)
                except Exception:
                    pass
    except KeyboardInterrupt:
        pass
    finally:
        renderer.finish()
        try:
            from obscura.cli.render import set_active_renderer

            set_active_renderer(None)
        except Exception:
            pass

    console.print()  # newline after streaming

    response_text = "".join(accumulated)

    # Track message history
    ctx.message_history.append(("user", text))
    if response_text:
        ctx.message_history.append(("assistant", response_text))

    # Parse plan if in PLAN mode
    _maybe_parse_plan(response_text, ctx)

    return response_text


# ---------------------------------------------------------------------------
# Async REPL
# ---------------------------------------------------------------------------


async def _repl(
    backend: str,
    model: str | None,
    system: str,
    session_id: str | None,
    max_turns: int,
    tools: str,
    prompt: str | None,
    confirm: bool,
    no_default_prompt: bool = False,
) -> None:
    """Core async loop — runs the interactive REPL or single-shot."""
    # Event store
    db_path = resolve_obscura_home() / "events.db"
    store = SQLiteEventStore(db_path)
    sid = session_id or uuid.uuid4().hex

    # Load .env best-effort
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except Exception:
        pass

    # Tool / MCP setup
    tools_enabled = tools == "on"
    mcp_configs: list[dict[str, Any]] = []
    mcp_names: list[str] = []
    if tools_enabled:
        mcp_configs, mcp_names = _discover_mcp()


    # Compose system prompt: default Obscura identity + user prompt + session memory
    import os
    from obscura.core.context import load_obscura_memory
    from obscura.core.system_prompts import compose_system_prompt

    include_default = not no_default_prompt
    if os.environ.get("OBSCURA_INCLUDE_DEFAULT_PROMPT", "true").lower() == "false":
        include_default = False

    memory_context = load_obscura_memory(sid, db_path)
    custom_sections = [memory_context] if memory_context else None
    combined_system = compose_system_prompt(
        base=system,
        include_default=include_default,
        custom_sections=custom_sections,
    )

    # Build client (MCP servers connect during start())
    async with ObscuraClient(
        backend,
        model=model,
        system_prompt=combined_system,
        mcp_servers=mcp_configs or None,
    ) as client:

        # Register built-in system tools
        tool_count = 0
        if tools_enabled:
            try:
                from obscura.tools.system import get_system_tool_specs

                specs = get_system_tool_specs()
                for spec in specs:
                    client.register_tool(spec)
                tool_count = len(specs)
            except Exception:
                pass

        # Register memory tools (always enabled, user-scoped to CLI user)
        try:
            import getpass as _getpass
            from obscura.auth.models import AuthenticatedUser as _AuthenticatedUser
            from obscura.tools.memory_tools import make_memory_tool_specs as _make_mem_specs

            _cli_user = _AuthenticatedUser(
                user_id=f"cli:{_getpass.getuser()}",
                email="",
                roles=("admin",),
                org_id=None,
                token_type="cli",
                raw_token="",
            )
            for _mem_spec in _make_mem_specs(_cli_user):
                client.register_tool(_mem_spec)
        except Exception:
            pass

        # Session resume
        if session_id:
            try:
                await client.resume_session(
                    SessionRef(session_id=session_id, backend=Backend(backend))
                )
            except Exception:
                pass

        # Build kwargs for run_loop
        loop_kwargs: dict[str, Any] = {}
        if not tools_enabled:
            loop_kwargs["tool_choice"] = ToolChoice.none()

        # Build REPL context
        ctx = REPLContext(
            client=client,
            store=store,
            session_id=sid,
            backend=backend,
            model=model,
            system_prompt=combined_system,
            max_turns=max_turns,
            tools_enabled=tools_enabled,
            mcp_configs=mcp_configs,
            confirm_enabled=confirm,
        )

        # --- Single-shot mode ---
        if prompt:
            try:
                await send_message(ctx, prompt, loop_kwargs)
            finally:
                try:
                    sess = await store.get_session(sid)
                    if sess is not None and sess.status == SessionStatus.RUNNING:
                        await store.update_status(sid, SessionStatus.COMPLETED)
                except Exception:
                    pass
                store.close()
            return

        # --- Interactive REPL ---
        mm = ctx.get_mode_manager()
        toolbar = f"mode: {mm.current.value} \u00b7 esc+enter multiline \u00b7 /help"
        session = create_prompt_session(COMPLETIONS, toolbar_text=toolbar)
        print_banner(
            backend,
            model,
            sid,
            tool_count=tool_count,
            mcp_servers=mcp_names or None,
            mode=mm.current.value,
        )

        background_tasks: set[asyncio.Task] = set()
        try:
            while True:
                try:
                    user_input = await bordered_prompt(session)
                except (EOFError, KeyboardInterrupt):
                    console.print()
                    break
                if not user_input:
                    continue

                # Slash command
                if user_input.startswith("/"):
                    if not ctx.tools_enabled:
                        loop_kwargs["tool_choice"] = ToolChoice.none()
                    else:
                        loop_kwargs.pop("tool_choice", None)

                    result = await handle_command(user_input, ctx)
                    if result == "quit":
                        break
                    continue

                # Rebuild loop_kwargs in case tools were toggled
                if not ctx.tools_enabled:
                    loop_kwargs["tool_choice"] = ToolChoice.none()
                else:
                    loop_kwargs.pop("tool_choice", None)

                # Chat message: run send_message in background so REPL remains responsive.
                status = console.status("[dim]› Streaming response...[/]", spinner="dots")
                try:
                    status.start()
                except Exception:
                    pass

                task = asyncio.create_task(send_message(ctx, user_input, loop_kwargs, external_status=status))
                background_tasks.add(task)

                # Remove task from set when done
                def _on_done(t: asyncio.Task) -> None:
                    try:
                        background_tasks.discard(t)
                    except Exception:
                        pass
                    try:
                        status.stop()
                    except Exception:
                        pass

                task.add_done_callback(_on_done)

        finally:
            # Wait for any streaming tasks to finish before shutdown
            if background_tasks:
                await asyncio.gather(*background_tasks, return_exceptions=True)
            await ctx.stop_runtime()
            try:
                sess = await store.get_session(sid)
                if sess is not None and sess.status == SessionStatus.RUNNING:
                    await store.update_status(sid, SessionStatus.COMPLETED)
            except Exception:
                pass
            store.close()


# ---------------------------------------------------------------------------
# Click entry point
# ---------------------------------------------------------------------------


def _list_sessions_and_exit(db_path: str) -> None:
    """Print recent sessions in a table and exit."""
    import asyncio as _asyncio
    from obscura.core.event_store import SQLiteEventStore as _SQLiteEventStore
    from rich.table import Table as _Table
    from rich.console import Console as _Console

    _console = _Console()

    async def _do_list() -> None:
        _store = _SQLiteEventStore(db_path)
        sessions = await _store.list_sessions()
        _store.close()
        if not sessions:
            _console.print("[dim]No sessions found.[/]")
            return
        table = _Table(show_header=True, header_style="bold cyan", title="Recent Sessions")
        table.add_column("Session ID", style="cyan", no_wrap=True)
        table.add_column("Status", style="yellow")
        table.add_column("Backend", style="green")
        table.add_column("Model", style="dim")
        table.add_column("Created", style="dim")
        for s in sessions[:30]:
            table.add_row(
                s.id,
                s.status.value,
                s.backend,
                s.model or "",
                s.created_at.strftime("%Y-%m-%d %H:%M"),
            )
        _console.print(table)
        _console.print("\n[dim]Resume with:[/] [bold]obscura --resume <session-id>[/]")

    _asyncio.run(_do_list())


@click.command()
@click.argument("prompt", required=False, default=None)
@click.option(
    "-b",
    "--backend",
    default="copilot",
    type=click.Choice(["copilot", "claude", "codex"]),
    help="Backend to use.",
)
@click.option("-m", "--model", default=None, help="Model ID override.")
@click.option("-s", "--system", default="", help="System prompt.")
@click.option(
    "--session",
    "--resume",
    "--continue",
    "session",
    default=None,
    help="Resume a previous session by ID (also: --resume, --continue).",
)
@click.option(
    "--sessions",
    "list_sessions",
    is_flag=True,
    default=False,
    help="List recent sessions and exit.",
)
@click.option("--max-turns", default=10, type=int, help="Max agent loop turns.")
@click.option(
    "--tools",
    default="on",
    type=click.Choice(["on", "off"]),
    help="Enable/disable tool calling.",
)
@click.option(
    "--confirm/--no-confirm",
    default=False,
    help="Require approval before each tool call.",
)
@click.option(
    "--no-default-prompt",
    is_flag=True,
    default=False,
    help="Skip the default Obscura system prompt.",
)
def main(
    prompt: str | None,
    backend: str,
    model: str | None,
    system: str,
    session: str | None,
    list_sessions: bool,
    max_turns: int,
    tools: str,
    confirm: bool,
    no_default_prompt: bool,
) -> None:
    """Obscura — AI agent REPL.

    Resume a session:  obscura --resume <session-id>
    List sessions:     obscura --sessions
    """
    if list_sessions:
        db_path = str(resolve_obscura_home() / "events.db")
        _list_sessions_and_exit(db_path)
        return

    try:
        asyncio.run(
            _repl(backend, model, system, session, max_turns, tools, prompt, confirm, no_default_prompt)
        )
    except KeyboardInterrupt:
        pass


# ---------------------------------------------------------------------------
# `obscura sessions` top-level command
# ---------------------------------------------------------------------------


@click.command("sessions")
@click.option("--limit", default=30, type=int, help="Max sessions to show.")
def sessions_cmd(limit: int) -> None:
    """List recent sessions. Resume with: obscura --resume <session-id>"""
    import asyncio as _asyncio
    from obscura.core.event_store import SQLiteEventStore as _SQLiteEventStore
    from rich.table import Table as _Table
    from rich.console import Console as _Console

    _console = _Console()

    async def _do() -> None:
        db_path = str(resolve_obscura_home() / "events.db")
        _store = _SQLiteEventStore(db_path)
        try:
            sessions = await _store.list_sessions()
        finally:
            _store.close()
        if not sessions:
            _console.print("[dim]No sessions found.[/]")
            return
        table = _Table(show_header=True, header_style="bold cyan", title="Recent Sessions")
        table.add_column("Session ID", style="cyan", no_wrap=True)
        table.add_column("Status", style="yellow")
        table.add_column("Backend", style="green")
        table.add_column("Model", style="dim")
        table.add_column("Created", style="dim")
        for s in sessions[:limit]:
            table.add_row(
                s.id,
                s.status.value,
                s.backend,
                s.model or "",
                s.created_at.strftime("%Y-%m-%d %H:%M"),
            )
        _console.print(table)
        _console.print("\n[dim]Resume with:[/] [bold]obscura --resume <session-id>[/]")

    _asyncio.run(_do())
